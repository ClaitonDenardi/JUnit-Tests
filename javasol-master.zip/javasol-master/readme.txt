README.txt
==========

How to build JavaSolitaire
--------------------------

I used ant v1.3 to compile and build JavaSolitaire.
You should download and install this software.
It's easy to find on Internet using a search engine.
It's also free.

Once ant is installed, you just need to type, at the command line :

/home/javasol$ ant run

If everything works fine, the application should start right away.

You can also double-click the file dist/javasol/index.html.  This should open the applet in your default browser.

